import boto3
from botocore.exceptions import ClientError
import pymysql
import os

def get_secret():
    secret_name = os.environ["DB_SECRET_NAME"]
    region_name = os.environ["AWS_REGION"]

    client = boto3.client("secretsmanager", region_name=region_name)

    response = client.get_secret_value(SecretId=secret_name)
    return response["SecretString"]

def lambda_handler(event, context):
    # Custom Resource only on Create
    if event.get("RequestType") != "Create":
        return {"Status": "SUCCESS"}

    s3 = boto3.client("s3")

    bucket = os.environ["SQL_BUCKET"]
    key    = os.environ["SQL_KEY"]

    sql = s3.get_object(
        Bucket=bucket,
        Key=key
    )["Body"].read().decode()

    conn = pymysql.connect(
        host=os.environ["DB_HOST"],
        user=os.environ["DB_USER"],
        password=get_secret(),
        database=os.environ["DB_NAME"],
        client_flag=pymysql.constants.CLIENT.MULTI_STATEMENTS
    )

    cur = conn.cursor()
    cur.execute(sql)
    conn.commit()

    cur.close()
    conn.close()
